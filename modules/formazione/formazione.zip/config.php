<?php
/**
 * Created by PhpStorm.
 * User: Fabrizio
 * Date: 02/04/2016
 * Time: 17:59
 */

$conf['formazione']['homepage']['seo_description'] = 'Corsi di formazione per la preparazione di esami universitari, di abilitazione o per professioni sanitarie per biologi, medici, farmacisti e professionisti.';
$conf['formazione']['homepage']['intro'] .= 'Benvenuti nel modulo "formazione" del portale BiologiaWiki.it';
$conf['formazione']['homepage']['title'] .= 'Corsi di formazione scientifica';