<?php
$version['formazione']['major'] = 1;
$version['formazione']['minor'] = 0;
$version['formazione']['build'] = 0;
$version['formazione']['dbSchema'] = 1;
$version['formazione']['author'] = 'fc';