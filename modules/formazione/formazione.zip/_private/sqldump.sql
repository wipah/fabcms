-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versione server:              10.4.7-MariaDB-log - mariadb.org binary distribution
-- S.O. server:                  Win64
-- HeidiSQL Versione:            11.0.0.5919
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT = @@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS = @@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS = 0 */;
/*!40101 SET @OLD_SQL_MODE = @@SQL_MODE, SQL_MODE = ''NO_AUTO_VALUE_ON_ZERO'' */;

-- Dump della struttura di tabella ftest.fabcms_formazione_courses
CREATE TABLE IF NOT EXISTS `fabcms_formazione_courses`
(
    `ID`                mediumint(8) unsigned           NOT NULL DEFAULT 0,
    `name`              varchar(255) CHARACTER SET utf8          DEFAULT NULL,
    `name_trackback`    varchar(255) CHARACTER SET utf8          DEFAULT NULL,
    `tags`              varchar(255) CHARACTER SET utf8          DEFAULT NULL,
    `avaliable_date`    date                                     DEFAULT NULL,
    `short_description` text CHARACTER SET utf8         NOT NULL,
    `SEO_description`   varchar(512) CHARACTER SET utf8 NOT NULL DEFAULT '' 0 '',
    `thumb_image`       varchar(255) CHARACTER SET utf8          DEFAULT NULL,
    `description`       text CHARACTER SET utf8         NOT NULL,
    `prestashop_ID`     int(11)                                  DEFAULT NULL,
    `subscription_link` varchar(255) CHARACTER SET utf8 NOT NULL,
    `avaliable`         bit(1)                                   DEFAULT b'' 0 '',
    `visible`           bit(1)                                   DEFAULT b'' 0 '',
    PRIMARY KEY (`ID`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf16;

-- L’esportazione dei dati non era selezionata.

-- Dump della struttura di tabella ftest.fabcms_formazione_courses_media
CREATE TABLE IF NOT EXISTS `fabcms_formazione_courses_media`
(
    `ID`           mediumint(8) unsigned NOT NULL DEFAULT 0,
    `course_ID`    mediumint(8) unsigned          DEFAULT NULL,
    `media_ID`     mediumint(8) unsigned          DEFAULT NULL,
    `access_level` tinyint(4) unsigned   NOT NULL DEFAULT 0,
    `order`        smallint(6) unsigned  NOT NULL DEFAULT 0,
    PRIMARY KEY (`ID`),
    KEY `course_ID` (`course_ID`),
    KEY `media_ID` (`media_ID`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf16;

-- L’esportazione dei dati non era selezionata.

-- Dump della struttura di tabella ftest.fabcms_formazione_courses_subscriptions
CREATE TABLE IF NOT EXISTS `fabcms_formazione_courses_subscriptions`
(
    `ID`            mediumint(8) unsigned NOT NULL DEFAULT 0,
    `user_ID`       mediumint(8) unsigned          DEFAULT NULL,
    `course_ID`     mediumint(8) unsigned          DEFAULT NULL,
    `purchase_date` date                           DEFAULT NULL,
    `expiring_date` date                           DEFAULT NULL,
    PRIMARY KEY (`ID`),
    KEY `user_ID` (`user_ID`),
    KEY `course_ID` (`course_ID`)
) ENGINE = InnoDB
  DEFAULT CHARSET = utf16;

-- L’esportazione dei dati non era selezionata.

/*!40101 SET SQL_MODE = IFNULL(@OLD_SQL_MODE, '''') */;
/*!40014 SET FOREIGN_KEY_CHECKS = IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT = @OLD_CHARACTER_SET_CLIENT */;
